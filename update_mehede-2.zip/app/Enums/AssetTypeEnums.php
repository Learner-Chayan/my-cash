<?php

namespace App\Enums;

enum AssetTypeEnums:int {
    case BDT = 100;
    case GOLD = 101;
    case PLATINUM = 102;
    case PALLADIUM = 103;
    case SILVER = 104;
}
