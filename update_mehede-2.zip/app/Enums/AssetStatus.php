<?php

namespace App\Enums;

interface AssetStatus {
    const UNLOCK = 1;
    const LOCK   = 2;
    const DELETE = 0;
}
