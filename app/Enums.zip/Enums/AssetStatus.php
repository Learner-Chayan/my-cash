<?php

namespace App\Enums;

interface AssetStatus {
    const UNLOCK = 15;
    const LOCK   = 16;
    const DELETE = 17;
}
