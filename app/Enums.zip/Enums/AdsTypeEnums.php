<?php

namespace App\Enums;

interface AdsTypeEnums {
    const SELL = 50;
    const BUY  = 51;
}
