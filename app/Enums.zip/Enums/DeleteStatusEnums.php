<?php 

namespace App\Enums;

interface DeleteStatusEnums {
    const DELETED = 76;
    const NOT_DELETED = 77;
}
