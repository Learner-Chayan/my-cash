<?php 

namespace App\Enums;

interface VisibilityStatusEnums {
    const ENABLE = 70;
    const DISABLE = 71;
}