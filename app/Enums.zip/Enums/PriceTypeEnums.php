<?php

namespace App\Enums;

interface PriceTypeEnums {
    const FIXED = 42;
    const FLOATING   = 43;
}
