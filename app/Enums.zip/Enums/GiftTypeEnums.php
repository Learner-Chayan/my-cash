<?php

namespace App\Enums;

interface GiftTypeEnums {

    const ALLUSER = 60;
    const NEWUSER = 61;
}
