<?php
namespace App\Enums;

interface AdsAdminApprovalEnums {
    const CHECKING = 65;
    const APPROVED = 66;
}
