<?php 

namespace App\Enums;

interface PermissionStatusEnums {
    const APPROVED = 73;
    const CHECKING = 75;
}