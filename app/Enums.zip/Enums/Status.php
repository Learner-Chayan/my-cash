<?php 

namespace App\Enums;

interface Status {
    const ACTIVE = 1;
    const INACTIVE = 2;
}