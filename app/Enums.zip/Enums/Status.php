<?php

namespace App\Enums;

interface Status {
    const ACTIVE = 20;
    const INACTIVE = 21;
}
