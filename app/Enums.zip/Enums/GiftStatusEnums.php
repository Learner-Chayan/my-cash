<?php

namespace App\Enums;

interface GiftStatusEnums{

    const PUBLISH = 55;
    const HIDE = 56;
}
