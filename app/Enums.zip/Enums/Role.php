<?php 

namespace App\Enums;

interface Role {
    const ADMIN = 2;
    const AGENT = 3;
    const REGULAR = 4;
    
}