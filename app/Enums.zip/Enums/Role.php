<?php 

namespace App\Enums;

interface Role {
    const ADMIN = 3;
    const AGENT = 4;
    const CUSTOMER =5;
    
}