<?php 

namespace App\Enums;

interface UserIdTypeEnums {
    const EMAIL = "email";
    const PHONE = "phone";
}