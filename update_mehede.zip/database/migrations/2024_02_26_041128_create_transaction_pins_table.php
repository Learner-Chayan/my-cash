<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transaction_pins', function (Blueprint $table) {
            $table->id();
            $table->string('transaction_id');
            $table->integer('pin');
            $table->dateTime('expiration_time');
            $table->integer('attemps')->default(3)->comment('3 means max attemp');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transaction_pins');
    }
};
